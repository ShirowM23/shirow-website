
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { FaTiktok, FaWhatsapp } from "react-icons/fa";

export default function HomePage() {
  const [email, setEmail] = useState("");

  return (
    <div className="min-h-screen bg-pink-50 text-gray-800">
      <header className="bg-black text-white p-6 shadow-md">
        <h1 className="text-3xl font-bold text-blue-400">SHIROW ENTERPRISE</h1>
        <p className="text-sm text-pink-300">Home of SHIRO CHIPS - Crunchy. Flavorful. Unforgettable.</p>
      </header>

      <section className="p-6 text-center bg-blue-100">
        <h2 className="text-2xl font-semibold mb-2 text-pink-600">Our Signature Product</h2>
        <p className="mb-4">SHIRO CHIPS – Loved by snack lovers and trusted by resellers. Now available for direct selling and distribution.</p>
        <Button className="text-white bg-black hover:bg-blue-700">Shop Now</Button>
      </section>

      <section className="p-6 grid md:grid-cols-2 gap-6">
        <Card className="bg-pink-100">
          <CardContent className="p-4">
            <h3 className="text-xl font-bold mb-2 text-blue-600">Why SHIRO CHIPS?</h3>
            <ul className="list-disc pl-6 text-left">
              <li>Locally made, globally loved</li>
              <li>Perfect for snacking or reselling</li>
              <li>Now accepting bulk orders</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-blue-50">
          <CardContent className="p-4">
            <h3 className="text-xl font-bold mb-2 text-pink-700">Become a Reseller</h3>
            <p>Join our growing community of snack distributors and direct sellers. No minimum order!</p>
            <Button className="mt-4 text-white bg-black hover:bg-blue-700">Register Now</Button>
          </CardContent>
        </Card>
      </section>

      <section className="p-6 bg-pink-100">
        <h3 className="text-xl font-bold mb-4 text-blue-700">Contact Us</h3>
        <form className="grid gap-4 max-w-md mx-auto">
          <Input placeholder="Your Name" required />
          <Input placeholder="Your Email" required type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input placeholder="Your Message" required />
          <Button type="submit" className="text-white bg-black hover:bg-blue-700">Send Message</Button>
        </form>
      </section>

      <footer className="p-6 text-center bg-black text-white mt-6">
        <div className="flex justify-center gap-6 mb-4">
          <a href="https://www.tiktok.com/@introvert23" target="_blank" rel="noopener noreferrer">
            <FaTiktok className="text-2xl hover:text-blue-300" />
          </a>
          <a href="https://wa.me/" target="_blank" rel="noopener noreferrer">
            <FaWhatsapp className="text-2xl hover:text-pink-300" />
          </a>
        </div>
        <p className="text-pink-300">&copy; {new Date().getFullYear()} SHIROW ENTERPRISE | www.shirow-entp.com</p>
      </footer>
    </div>
  );
}
